# Pocket Goose V3

Android Studio/Gradle project for Pocket Goose. Package: `com.pocketgoose.app`.

V3 keeps the V2 character artwork, adds a newly synthesised goose-like honk, improved movement cadence, little idle/step bounce, occasional excited hops, sleep behaviour, dragging, overlay service and persistent size/speed/sound preferences.

Build: `gradle assembleDebug` with Java 17 and Android SDK platform 35. APK: `app/build/outputs/apk/debug/app-debug.apk`.

Note: this is a release-candidate iteration, not a fully skeletal animation rig. The current character is a single flattened illustration, so independent head/wing/foot sprite articulation still requires separated art layers.
