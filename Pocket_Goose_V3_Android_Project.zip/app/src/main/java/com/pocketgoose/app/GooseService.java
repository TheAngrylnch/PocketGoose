package com.pocketgoose.app;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.Random;

public class GooseService extends Service {
 public static final String ACTION_START="START_GOOSE", ACTION_STOP="STOP_GOOSE";
 private WindowManager wm; private ImageView goose; private WindowManager.LayoutParams params;
 private final Handler handler=new Handler(Looper.getMainLooper()); private final Random random=new Random();
 private boolean dragging=false,sleeping=false; private float downX,downY,startX,startY,vx=1.8f,vy=.35f;
 private int size=150,tick=0; private long lastTouch=System.currentTimeMillis(),sleepUntil=0;
 private Runnable loop; private MediaPlayer player;
 private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
 @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);createChannel();}
 @Override public int onStartCommand(Intent intent,int flags,int id){String a=intent==null?ACTION_START:intent.getAction();if(ACTION_STOP.equals(a)){stopGoose();stopForeground(true);stopSelf();return START_NOT_STICKY;}if(Build.VERSION.SDK_INT>=26)startForeground(7,notification());if(Settings.canDrawOverlays(this))showGoose();return START_STICKY;}
 private void showGoose(){if(goose!=null)return;android.content.SharedPreferences prefs=getSharedPreferences("goose",MODE_PRIVATE);size=prefs.getInt("size",150);goose=new ImageView(this);goose.setImageResource(R.drawable.goose);goose.setScaleType(ImageView.ScaleType.FIT_CENTER);goose.setLayerType(View.LAYER_TYPE_HARDWARE,null);
 params=new WindowManager.LayoutParams(dp(size),dp((int)(size*1.43f)),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);params.gravity=Gravity.TOP|Gravity.LEFT;params.x=dp(75);params.y=dp(310);
 goose.setOnTouchListener((v,e)->{switch(e.getAction()){case MotionEvent.ACTION_DOWN:downX=e.getRawX();downY=e.getRawY();startX=params.x;startY=params.y;dragging=false;lastTouch=System.currentTimeMillis();sleeping=false;return true;case MotionEvent.ACTION_MOVE:float mx=e.getRawX()-downX,my=e.getRawY()-downY;if(Math.abs(mx)>dp(5)||Math.abs(my)>dp(5))dragging=true;if(dragging){params.x=(int)(startX+mx);params.y=(int)(startY+my);try{wm.updateViewLayout(goose,params);}catch(Exception ignored){}}return true;case MotionEvent.ACTION_UP:if(!dragging)honk();lastTouch=System.currentTimeMillis();return true;}return true;});
 try{wm.addView(goose,params);startLoop();}catch(Exception e){goose=null;}}
 private void startLoop(){loop=new Runnable(){public void run(){if(goose==null)return;tick++;long now=System.currentTimeMillis();int sl=getSharedPreferences("goose",MODE_PRIVATE).getInt("speed",2);float sf=new float[]{.45f,.7f,1f,1.35f,1.8f}[Math.max(0,Math.min(4,sl))];
 if(!dragging){if(now-lastTouch>52000&&!sleeping&&random.nextInt(220)==0){sleeping=true;sleepUntil=now+10000;goose.animate().rotation(-7).scaleY(.94f).setDuration(450).start();}if(sleeping&&now>sleepUntil){sleeping=false;goose.animate().rotation(0).scaleY(1).setDuration(500).start();lastTouch=now;}
 if(!sleeping){int sw=wm.getDefaultDisplay().getWidth(),sh=wm.getDefaultDisplay().getHeight();params.x+=(int)(vx*sf);params.y+=(int)(vy*sf);int maxX=Math.max(dp(4),sw-dp(size)-dp(4)),maxY=Math.max(dp(80),sh-dp(size*1.43f)-dp(110));if(params.x<0||params.x>maxX){vx=-vx;params.x=Math.max(0,Math.min(maxX,params.x));}if(params.y<dp(24)||params.y>maxY){vy=-vy;params.y=Math.max(dp(24),Math.min(maxY,params.y));}if(random.nextInt(130)==0){vx=(random.nextFloat()*2.8f+.7f)*(random.nextBoolean()?1:-1);vy=random.nextFloat()*1.1f-.55f;}try{wm.updateViewLayout(goose,params);}catch(Exception ignored){}float dir=vx<0?-1:1;goose.setScaleX(dir);float phase=now/115.0f;goose.setTranslationY((float)Math.sin(phase)*dp(2.4f));
 // A visible stepping rhythm: short alternating squash/stretch while he wanders.
 float step=(float)Math.sin(now/105.0);goose.setScaleY(1f+Math.max(0,step)*.018f);goose.setRotation((float)Math.sin(now/360.0)*1.8f);
 // Occasional excited hop and wing-like body flutter.
 if(tick%900==0&&random.nextBoolean())goose.animate().translationY(-dp(13)).rotationBy(4).setDuration(180).withEndAction(()->{if(goose!=null)goose.animate().translationY(0).rotation(0).setDuration(260).start();}).start();
 }}handler.postDelayed(this,45);}};handler.post(loop);}
 private void honk(){android.content.SharedPreferences prefs=getSharedPreferences("goose",MODE_PRIVATE);if(prefs.getBoolean("sound",true)){try{if(player!=null){player.release();player=null;}player=MediaPlayer.create(this,R.raw.honk);if(player!=null){player.setOnCompletionListener(mp->{mp.release();if(player==mp)player=null;});player.start();}}catch(Exception ignored){}}
 if(goose!=null){goose.animate().cancel();float d=vx<0?-1:1;goose.animate().scaleX(d*1.12f).scaleY(.88f).rotation(6).setDuration(100).withEndAction(()->{if(goose!=null)goose.animate().scaleX(vx<0?-1:1).scaleY(1).rotation(0).setDuration(240).start();}).start();}}
 private void stopGoose(){if(loop!=null)handler.removeCallbacks(loop);if(player!=null){player.release();player=null;}if(goose!=null){try{wm.removeView(goose);}catch(Exception ignored){}goose=null;}}
 @Override public void onDestroy(){stopGoose();super.onDestroy();}@Override public IBinder onBind(Intent i){return null;}
 private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("goose_channel","Pocket Goose",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
 private Notification notification(){Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);return new Notification.Builder(this,"goose_channel").setContentTitle("Pocket Goose is roaming").setContentText("Tap your adventurer goose to hear his honk.").setSmallIcon(android.R.drawable.ic_menu_compass).setContentIntent(pi).setOngoing(true).build();}
}
