# Pocket Goose V2

A floating Android goose companion for Android 8+.

## V2 improvements
- Cleaner transparent cut-out from the original character artwork.
- New synthesized nasal goose-style honk.
- Smoother wandering, gentle bobbing and turning.
- Idle nap behaviour.
- Settings for size, wandering speed and honk sound.
- Keeps drag-to-move and tap-to-honk overlay controls.

## Build
Requires JDK 17 and Gradle 8.9:
`gradle assembleDebug`

APK: `app/build/outputs/apk/debug/app-debug.apk`

The app uses the Android overlay permission and a foreground service so the goose can remain visible over other apps.
