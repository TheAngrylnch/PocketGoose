package com.pocketgoose.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    private TextView status;
    private android.content.SharedPreferences prefs;
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("goose",MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.rgb(42,31,27));
        getWindow().setNavigationBarColor(Color.rgb(42,31,27));
        ScrollView scroll=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22),dp(24),dp(22),dp(22));root.setBackgroundColor(Color.rgb(247,237,215));
        scroll.addView(root);

        TextView title=new TextView(this);title.setText("Pocket Goose  •  V2");title.setTextSize(29);
        title.setTypeface(Typeface.SERIF,Typeface.BOLD);title.setTextColor(Color.rgb(87,43,29));root.addView(title);
        TextView sub=new TextView(this);sub.setText("A tiny adventurer with a much better honk.");sub.setTextSize(15);
        sub.setTextColor(Color.rgb(110,79,57));root.addView(sub);

        ImageView preview=new ImageView(this);preview.setImageResource(R.drawable.goose);preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(260));pp.topMargin=dp(8);pp.bottomMargin=dp(8);root.addView(preview,pp);

        status=new TextView(this);status.setText("● Ready for adventure.");status.setTextSize(15);
        status.setTextColor(Color.rgb(65,102,59));status.setPadding(0,dp(8),0,dp(12));root.addView(status);

        Button summon=button("SUMMON GOOSE");
        summon.setOnClickListener(v->{
            if(!Settings.canDrawOverlays(this)){
                status.setText("Allow Display over other apps, then return here.");
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));
            }else{
                if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=0)
                    requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},44);
                Intent s=new Intent(this,GooseService.class);s.setAction(GooseService.ACTION_START);
                if(Build.VERSION.SDK_INT>=26)startForegroundService(s);else startService(s);
                status.setText("● Sir Honksalot is roaming.");
            }
        });root.addView(summon,new LinearLayout.LayoutParams(-1,dp(56)));

        Button dismiss=button("SEND GOOSE AWAY");
        dismiss.setOnClickListener(v->{Intent s=new Intent(this,GooseService.class);s.setAction(GooseService.ACTION_STOP);startService(s);status.setText("● Goose has waddled off.");});
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(52));bp.topMargin=dp(9);root.addView(dismiss,bp);

        TextView settings=new TextView(this);settings.setText("COMPANION SETTINGS");settings.setTextSize(18);
        settings.setTypeface(Typeface.SERIF,Typeface.BOLD);settings.setTextColor(Color.rgb(87,43,29));
        settings.setPadding(0,dp(22),0,dp(5));root.addView(settings);

        addLabel(root,"Goose size");
        SeekBar size=new SeekBar(this);size.setMax(130);size.setProgress(prefs.getInt("size",150)-100);
        root.addView(size);TextView sizeValue=label("150 dp");root.addView(sizeValue);
        size.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int p,boolean u){sizeValue.setText((p+100)+" dp");if(u)prefs.edit().putInt("size",p+100).apply();}
            public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
        });

        addLabel(root,"Wandering speed");
        SeekBar speed=new SeekBar(this);speed.setMax(4);speed.setProgress(prefs.getInt("speed",2));root.addView(speed);
        TextView speedValue=label(speedName(speed.getProgress()));root.addView(speedValue);
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int p,boolean u){speedValue.setText(speedName(p));if(u)prefs.edit().putInt("speed",p).apply();}
            public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
        });

        CheckBox sound=new CheckBox(this);sound.setText("Honk when tapped");sound.setTextSize(15);sound.setTextColor(Color.rgb(92,75,62));
        sound.setChecked(prefs.getBoolean("sound",true));sound.setOnCheckedChangeListener((b1,c)->prefs.edit().putBoolean("sound",c).apply());root.addView(sound);

        TextView note=new TextView(this);note.setText("Tap him to honk. Drag him anywhere. Leave him alone and he'll explore, bob about and occasionally have a nap. Settings apply the next time you summon him.");
        note.setTextSize(14);note.setTextColor(Color.rgb(92,75,62));note.setPadding(0,dp(16),0,0);root.addView(note);
        setContentView(scroll);
    }

    private String speedName(int p){return new String[]{"Very slow","Gentle","Normal","Lively","Zoomies"}[p];}
    private void addLabel(LinearLayout root,String s){TextView t=label(s);t.setTypeface(Typeface.DEFAULT_BOLD);root.addView(t);}
    private TextView label(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(14);t.setTextColor(Color.rgb(92,75,62));return t;}
    private Button button(String text){Button b=new Button(this);b.setText(text);b.setTextSize(16);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(126,58,39)));return b;}
}
