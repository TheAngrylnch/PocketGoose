package com.pocketgoose.app;

import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.media.MediaPlayer;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.ImageView;
import java.util.Random;

/** Persistent, battery-conscious floating companion. */
public class GooseService extends Service {
    public static final String ACTION_START="com.pocketgoose.START", ACTION_STOP="com.pocketgoose.STOP", ACTION_PAUSE="com.pocketgoose.PAUSE", ACTION_RESUME="com.pocketgoose.RESUME", ACTION_HONK="com.pocketgoose.HONK", ACTION_REFRESH="com.pocketgoose.REFRESH";
    private WindowManager wm; private ImageView goose; private WindowManager.LayoutParams params;
    private final Handler handler=new Handler(Looper.getMainLooper()); private final Random rng=new Random();
    private boolean paused=false, dragging=false, following=false, sleeping=false; private float downX,downY,startX,startY,vx=1.35f,vy=.25f; private int size=154,tick=0; private long lastTouch=System.currentTimeMillis(),sleepUntil=0; private Runnable loop; private MediaPlayer player;
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);} 
    private android.content.SharedPreferences prefs(){return getSharedPreferences("goose",MODE_PRIVATE);} 
    @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);createChannel();}
    @Override public int onStartCommand(Intent i,int flags,int id){String a=i==null?ACTION_START:i.getAction(); if(ACTION_STOP.equals(a)){stopGoose();stopForeground(true);stopSelf();return START_NOT_STICKY;} if(Build.VERSION.SDK_INT>=26)startForeground(7,notification()); if(!Settings.canDrawOverlays(this))return START_NOT_STICKY; if(ACTION_PAUSE.equals(a)){paused=true;return START_STICKY;} if(ACTION_RESUME.equals(a)){paused=false;lastTouch=System.currentTimeMillis();return START_STICKY;} if(ACTION_HONK.equals(a)){honk();return START_STICKY;} if(ACTION_REFRESH.equals(a)){refreshSize();return START_STICKY;} if(goose==null)showGoose(); return START_STICKY;}
    private void showGoose(){size=prefs().getInt("size",154); goose=new ImageView(this);goose.setImageResource(R.drawable.goose);goose.setScaleType(ImageView.ScaleType.FIT_CENTER);goose.setLayerType(View.LAYER_TYPE_HARDWARE,null);
        params=new WindowManager.LayoutParams(dp(size),dp((int)(size*1.43f)),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);params.gravity=Gravity.TOP|Gravity.LEFT;params.x=dp(60);params.y=dp(260);
        goose.setOnTouchListener((v,e)->{switch(e.getAction()){case MotionEvent.ACTION_DOWN:downX=e.getRawX();downY=e.getRawY();startX=params.x;startY=params.y;dragging=false;lastTouch=System.currentTimeMillis();sleeping=false;return true;case MotionEvent.ACTION_MOVE:float mx=e.getRawX()-downX,my=e.getRawY()-downY;if(Math.abs(mx)>dp(5)||Math.abs(my)>dp(5))dragging=true;if(dragging){params.x=(int)(startX+mx);params.y=(int)(startY+my);clamp();update();}return true;case MotionEvent.ACTION_UP:if(!dragging){if(prefs().getBoolean("follow",false)){following=!following;vx=following?0:1.2f;}else honk();}lastTouch=System.currentTimeMillis();return true;}return true;});
        try{wm.addView(goose,params);startLoop();}catch(Exception ex){goose=null;}}
    private void refreshSize(){if(goose==null)return;size=prefs().getInt("size",154);params.width=dp(size);params.height=dp((int)(size*1.43f));update();}
    private void clamp(){if(params==null)return;int sw=wm.getDefaultDisplay().getWidth(),sh=wm.getDefaultDisplay().getHeight();params.x=Math.max(0,Math.min(Math.max(0,sw-params.width),params.x));params.y=Math.max(dp(24),Math.min(Math.max(dp(24),sh-params.height-dp(90)),params.y));}
    private void update(){try{if(goose!=null)wm.updateViewLayout(goose,params);}catch(Exception ignored){}}
    private void startLoop(){if(loop!=null)handler.removeCallbacks(loop);loop=new Runnable(){@Override public void run(){if(goose==null)return;long now=System.currentTimeMillis();tick++;if(!paused&&!dragging){if(now-lastTouch>prefs().getInt("nap",75)*1000L&&!sleeping&&rng.nextInt(100)==0){sleeping=true;sleepUntil=now+12000;goose.animate().rotation(-8).scaleY(.94f).setDuration(500).start();}if(sleeping&&now>sleepUntil){sleeping=false;goose.animate().rotation(0).scaleY(1).setDuration(450).start();lastTouch=now;}
        if(!sleeping&&!following){int speed=Math.max(0,Math.min(4,prefs().getInt("speed",2)));float factor=new float[]{.35f,.62f,.95f,1.35f,1.8f}[speed];params.x+=(int)(vx*factor);params.y+=(int)(vy*factor);int sw=wm.getDefaultDisplay().getWidth(),sh=wm.getDefaultDisplay().getHeight();int maxX=Math.max(0,sw-params.width),maxY=Math.max(dp(24),sh-params.height-dp(90));if(params.x<0||params.x>maxX){vx=-vx;params.x=Math.max(0,Math.min(maxX,params.x));}if(params.y<dp(24)||params.y>maxY){vy=-vy;params.y=Math.max(dp(24),Math.min(maxY,params.y));}if(rng.nextInt(170)==0){vx=(.7f+rng.nextFloat()*1.7f)*(rng.nextBoolean()?1:-1);vy=(rng.nextFloat()-.5f)*.9f;}update();}
        if(!sleeping){float direction=following?1:(vx<0?-1:1);goose.setScaleX(direction);float phase=now/115f;goose.setTranslationY((float)Math.sin(phase)*dp(2));goose.setRotation((float)Math.sin(now/420f)*1.3f);goose.setScaleY(1f+(float)Math.max(0,Math.sin(now/105f))*.012f);if(tick%720==0&&rng.nextInt(3)==0)hop();}
    }handler.postDelayed(this,55);}};handler.post(loop);}
    private void hop(){if(goose==null)return;goose.animate().cancel();goose.animate().translationY(-dp(15)).rotation(4).setDuration(190).withEndAction(()->{if(goose!=null)goose.animate().translationY(0).rotation(0).setDuration(260).start();}).start();}
    private void honk(){lastTouch=System.currentTimeMillis();if(prefs().getBoolean("sound",true)){try{if(player!=null){player.release();player=null;}player=MediaPlayer.create(this,R.raw.honk);if(player!=null){player.setVolume(prefs().getFloat("volume",.8f),prefs().getFloat("volume",.8f));player.setOnCompletionListener(mp->{mp.release();if(player==mp)player=null;});player.start();}}catch(Exception ignored){}}if(goose!=null){goose.animate().cancel();float d=following?1:(vx<0?-1:1);goose.animate().scaleX(d*1.1f).scaleY(.9f).rotation(5).setDuration(110).withEndAction(()->{if(goose!=null)goose.animate().scaleX(following?1:(vx<0?-1:1)).scaleY(1).rotation(0).setDuration(220).start();}).start();}}
    private void stopGoose(){if(loop!=null)handler.removeCallbacks(loop);loop=null;if(player!=null){player.release();player=null;}if(goose!=null){try{wm.removeView(goose);}catch(Exception ignored){}goose=null;}}
    @Override public void onDestroy(){stopGoose();super.onDestroy();}@Override public IBinder onBind(Intent i){return null;}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("goose_channel","Pocket Goose",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    private PendingIntent action(String a,int n){Intent i=new Intent(this,GooseService.class);i.setAction(a);return PendingIntent.getService(this,n,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);}
    private Notification notification(){Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);return new Notification.Builder(this,"goose_channel").setContentTitle("Pocket Goose is roaming").setContentText(paused?"Taking a little break.":"Tap the goose to hear him honk.").setSmallIcon(android.R.drawable.ic_menu_compass).setContentIntent(pi).addAction(new Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this,android.R.drawable.ic_btn_speak_now),"Honk",action(ACTION_HONK,1)).build()).addAction(new Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this,android.R.drawable.ic_media_pause),paused?"Resume":"Pause",action(paused?ACTION_RESUME:ACTION_PAUSE,2)).build()).setOngoing(true).build();}
}
