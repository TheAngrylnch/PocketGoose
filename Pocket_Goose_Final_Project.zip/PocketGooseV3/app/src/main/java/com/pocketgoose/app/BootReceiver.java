package com.pocketgoose.app;
import android.content.*;import android.os.Build;import android.provider.Settings;
public class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){if(Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())){if(c.getSharedPreferences("goose",Context.MODE_PRIVATE).getBoolean("boot",false)&&Settings.canDrawOverlays(c)){Intent s=new Intent(c,GooseService.class);s.setAction(GooseService.ACTION_START);if(Build.VERSION.SDK_INT>=26)c.startForegroundService(s);else c.startService(s);}}}
}
