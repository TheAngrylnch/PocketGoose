# Pocket Goose — 1.0.0 release candidate

Native Android floating companion for the Samsung Galaxy S23+ and Android 8.0+.

## Included
- Floating overlay with drag positioning and edge-aware roaming
- Tap-to-honk with volume control
- Pause/resume and honk notification actions
- Saved size, speed, sound, tap-follow and start-after-reboot preferences
- Sleep/awake idle behaviour, directional facing, subtle walk bounce and occasional hops
- Foreground service while roaming; stop control removes the overlay and service
- Warm parchment control panel and persistent settings

## Honest animation note
The supplied Pocket Goose artwork is a single flattened illustration. This release animates the complete illustration (movement, facing, idle motion, sleep, hop and honk reaction). It does **not** yet have independent head, wing, beak or foot rigs. Those require a separately illustrated and aligned set of transparent character layers or a purpose-made frame animation. The existing character art is retained; no substitute character has been introduced.

## Build
Use Java 17, Gradle 8.9+ and Android SDK platform 35. Run `gradle assembleDebug`. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.

## First launch
1. Install the APK and open Pocket Goose.
2. Tap **SUMMON** and allow **Display over other apps**.
3. Return to Pocket Goose and tap **SUMMON** again.
4. Allow notifications if Android asks. The notification provides quick honk and pause controls.
5. Enable reboot launch only if you want Pocket Goose to return after a phone restart. Android may still apply its own background/battery rules.

## Notes
- Android overlay and notification permissions are controlled by Android settings.
- Samsung battery optimisation may affect long-running background behaviour; set Pocket Goose to unrestricted only if you want it to remain active consistently.
- This is a debug-signed APK for personal testing, not a Play Store release.
