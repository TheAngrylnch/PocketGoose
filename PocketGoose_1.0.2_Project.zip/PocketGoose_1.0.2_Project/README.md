# Pocket Goose 1.0.2

This is the Android Studio / GitHub Actions project for Pocket Goose.

## Changes in 1.0.2
- Keeps the existing Pocket Goose character artwork and floating companion service.
- Adds a visible startup diagnostic screen if the launcher throws an exception, rather than silently returning to the home screen.
- Clamps stored size, speed and volume preferences to valid ranges.
- Uses versionCode 6 / versionName 1.0.2 and target SDK 34 for a conservative Android compatibility baseline.

## Build
Run `gradle assembleDebug`. The APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

GitHub Actions workflow: `.github/workflows/build.yml`.

Note: a successful build does not prove runtime behaviour on a particular handset. The diagnostic screen is intended to expose launcher exceptions during device testing.
