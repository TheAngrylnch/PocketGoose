package com.pocketgoose.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    private TextView status;
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(42,31,27));
        getWindow().setNavigationBarColor(Color.rgb(42,31,27));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(24), dp(22), dp(20));
        root.setBackgroundColor(Color.rgb(247,237,215));

        TextView title = new TextView(this);
        title.setText("🪿 Pocket Goose");
        title.setTextSize(30); title.setTypeface(Typeface.SERIF, Typeface.BOLD);
        title.setTextColor(Color.rgb(87,43,29));
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Your tiny chaotic companion");
        subtitle.setTextSize(16); subtitle.setTextColor(Color.rgb(110,79,57));
        root.addView(subtitle);

        ImageView preview = new ImageView(this);
        preview.setImageResource(R.drawable.goose);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(280));
        pp.topMargin = dp(12); pp.bottomMargin = dp(12);
        root.addView(preview, pp);

        status = new TextView(this);
        status.setText("● Goose is waiting for orders.");
        status.setTextSize(15); status.setTextColor(Color.rgb(65,102,59));
        status.setPadding(0, dp(8), 0, dp(14));
        root.addView(status);

        Button summon = button("SUMMON GOOSE");
        summon.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                status.setText("Please allow Display over other apps, then return here.");
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0)
                    requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 44);
                Intent s = new Intent(this, GooseService.class);
                s.setAction(GooseService.ACTION_START);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
                status.setText("● Sir Honksalot has entered the premises.");
            }
        });
        root.addView(summon, new LinearLayout.LayoutParams(-1, dp(58)));

        Button dismiss = button("SEND GOOSE AWAY");
        dismiss.setOnClickListener(v -> {
            Intent s = new Intent(this, GooseService.class);
            s.setAction(GooseService.ACTION_STOP);
            startService(s);
            status.setText("● Goose has waddled off. Probably.");
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(54));
        bp.topMargin = dp(10);
        root.addView(dismiss, bp);

        TextView hint = new TextView(this);
        hint.setText("\nTap the floating goose to honk. Drag him to move him. Leave him alone and he'll wander about.\n\nTip: grant “Display over other apps” when Android asks.");
        hint.setTextSize(14); hint.setTextColor(Color.rgb(92,75,62));
        root.addView(hint);

        setContentView(root);
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text); b.setTextSize(16); b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(126,58,39)));
        return b;
    }
}
