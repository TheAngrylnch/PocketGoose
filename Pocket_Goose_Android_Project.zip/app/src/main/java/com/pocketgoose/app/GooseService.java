package com.pocketgoose.app;

import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.media.MediaPlayer;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import android.graphics.drawable.Drawable;
import java.util.Random;

public class GooseService extends Service {
    public static final String ACTION_START="START_GOOSE", ACTION_STOP="STOP_GOOSE";
    private WindowManager wm;
    private ImageView goose;
    private WindowManager.LayoutParams params;
    private Handler handler = new Handler(Looper.getMainLooper());
    private Random random = new Random();
    private boolean moving=false, dragging=false;
    private float downX, downY, startX, startY;
    private int dx=4, dy=2;
    private int size=150;
    private long lastTouch=0;
    private Runnable wander = new Runnable() {
        @Override public void run() {
            if (goose == null) return;
            if (!dragging && moving) {
                int maxX = Math.max(1, wm.getDefaultDisplay().getWidth()-size);
                int maxY = Math.max(1, wm.getDefaultDisplay().getHeight()-size-80);
                params.x += dx; params.y += dy;
                if (params.x < 0 || params.x > maxX) dx = -dx;
                if (params.y < 0 || params.y > maxY) dy = -dy;
                if (random.nextInt(35)==0) { dx = random.nextInt(9)-4; dy=random.nextInt(7)-3; }
                if (dx==0 && dy==0) dx=2;
                try { wm.updateViewLayout(goose, params); } catch(Exception ignored) {}
                goose.setScaleX(dx < 0 ? -1f : 1f);
                goose.setTranslationY((float)Math.sin(System.currentTimeMillis()/170.0)*dp(3));
            }
            handler.postDelayed(this, 70);
        }
    };

    private int dp(float v) { return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    @Override public void onCreate() {
        super.onCreate();
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int id) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) { stopGoose(); stopForeground(true); stopSelf(); return START_NOT_STICKY; }
        if (Build.VERSION.SDK_INT >= 26) {
            startForeground(7, notification());
        }
        if (Settings.canDrawOverlays(this)) showGoose();
        return START_STICKY;
    }

    private void showGoose() {
        if (goose != null) return;
        goose = new ImageView(this);
        goose.setImageResource(R.drawable.goose);
        goose.setScaleType(ImageView.ScaleType.FIT_CENTER);
        params = new WindowManager.LayoutParams(dp(150), dp(180),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.LEFT;
        params.x=dp(90); params.y=dp(360);
        goose.setOnTouchListener((v,e)->{
            switch(e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downX=e.getRawX(); downY=e.getRawY();
                    startX=params.x; startY=params.y; dragging=false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float mx=e.getRawX()-downX, my=e.getRawY()-downY;
                    if (Math.abs(mx)>dp(5)||Math.abs(my)>dp(5)) dragging=true;
                    if (dragging) {
                        params.x=(int)(startX+mx); params.y=(int)(startY+my);
                        try { wm.updateViewLayout(goose,params); } catch(Exception ignored) {}
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!dragging) honk();
                    return true;
            }
            return true;
        });
        try { wm.addView(goose,params); moving=true; handler.post(wander); }
        catch(Exception e) { goose=null; }
    }

    private void honk() {
        try {
            MediaPlayer mp=MediaPlayer.create(this,R.raw.honk);
            if(mp!=null){ mp.setOnCompletionListener(MediaPlayer::release); mp.start(); }
        } catch(Exception ignored) {}
        if(goose!=null) {
            goose.animate().scaleX(1.18f).scaleY(0.88f).setDuration(100)
                .withEndAction(()->{ if(goose!=null) goose.animate().scaleX(1f).scaleY(1f).setDuration(180).start(); }).start();
        }
    }

    private void stopGoose() {
        moving=false; handler.removeCallbacksAndMessages(null);
        if(goose!=null) { try { wm.removeView(goose); } catch(Exception ignored) {} goose=null; }
    }
    @Override public void onDestroy(){ stopGoose(); super.onDestroy(); }
    @Override public IBinder onBind(Intent i){ return null; }

    private void createChannel() {
        if(Build.VERSION.SDK_INT>=26) {
            NotificationChannel c=new NotificationChannel("goose_channel","Pocket Goose",NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    private Notification notification() {
        Intent open=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this,"goose_channel")
            .setContentTitle("Pocket Goose is roaming")
            .setContentText("Tap the goose to hear him honk.")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi).setOngoing(true).build();
    }
}
