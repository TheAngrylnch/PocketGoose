# Pocket Goose — Android starter project

A first playable prototype for the Samsung Galaxy S23+.

## Included in this prototype
- Main app screen with summon/dismiss controls
- Floating overlay goose
- Drag to reposition
- Automatic wandering
- Tap-to-honk sound and bounce
- Foreground notification while the overlay is active

## Important
This is an early prototype, not the finished feature set. Sleep, finger-following, settings persistence, costume changes, and frame-by-frame animation are planned follow-ups.

## Build
This is a standard Android Gradle project (Java, minSdk 26, compileSdk 35). It can be built with Android Studio or the included GitHub Actions workflow.

To build in GitHub:
1. Create a new GitHub repository.
2. Upload the contents of this folder.
3. Open Actions and run "Build Pocket Goose APK" (or push to main).
4. Download the `Pocket-Goose-debug` artifact and install the APK on your phone.

On first launch, press SUMMON GOOSE and grant Android's "Display over other apps" permission. Android may also ask for notification permission.

## Samsung notes
If One UI suspends the companion, set Pocket Goose battery usage to Unrestricted in Settings > Apps > Pocket Goose > Battery.
